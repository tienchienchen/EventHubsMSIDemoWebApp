# Managed Service Identity sample #

For more information on Managed Service Identity (MSI) and how to run this sample follow [this](https://docs.microsoft.com/en-us/azure/event-hubs/event-hubs-managed-service-identity) link.

